
const button = document.querySelector('#btn');
const button1 = document.querySelector('#btn1');
const list = document.querySelector('#list');
let to_do_list = [];

button.onclick = function(){
    let item = document.querySelector("#todo").value;
    console.log(item);
    to_do_list.push(item);
    document.getElementById("list").innerHTML = to_do_list;
    localStorage.setItem('Product', to_do_list);
    document.forms.myForm.reset();
}
button1.onclick = function(){
    to_do_list.pop();
    document.getElementById("list").innerHTML = to_do_list;
    localStorage.setItem('Product', to_do_list);
}


